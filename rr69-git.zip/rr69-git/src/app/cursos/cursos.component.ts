import { Component, OnInit } from '@angular/core';
import { CursosService } from './cursos.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-cursos',
  templateUrl: './cursos.component.html'
})
export class CursosComponent implements OnInit {

  cursos: any [];
  pagina: number;

  constructor(private cursosService: CursosService,
              private route: ActivatedRoute,
              private router: Router
            ) { }

  ngOnInit() {
    this.cursos = this.cursosService.getCursos();


    this.route.queryParams.subscribe(
      (queryParams: any) => {
        this.pagina = queryParams['pagina'];
      }
    );
  }

  proximaPagina(){
    // this.pagina++;
    this.router.navigate(['/cursos'],
          {queryParams: {'pagina': ++this.pagina}}
  );
}
}
