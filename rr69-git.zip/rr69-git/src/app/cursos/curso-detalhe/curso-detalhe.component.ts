import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CursosService } from './../cursos.service';

@Component({
  selector: 'app-curso-detalhe',
  templateUrl: './curso-detalhe.component.html'
 })

export class CursoDetalheComponent implements OnInit {

  id: number;
  curso: any;

  constructor(private route: ActivatedRoute,
              private router: Router,
// a classe Router é necessária por causa dos redirecionamento
              private cursosService: CursosService)
         // tslint:disable-next-line:one-line
         {
//        this.id = this.route.snapshot.params['id'];
   }

   ngOnInit () {[
    this.route.params.subscribe(
      (params: any) => {
        this.id = params['id'];

        this.curso = this.cursosService.getCurso(this.id);

        // tslint:disable-next-line:one-line
        if (this.curso == null){
           this.router.navigate([ '/cursos/naoEncontrado' ]);

        }
      }
    )
  ];
}
}

