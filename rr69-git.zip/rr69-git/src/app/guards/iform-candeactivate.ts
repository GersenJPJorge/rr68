export interface IFormCandeactivate {
    podeDesativar();
}