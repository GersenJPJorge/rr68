import { AuthService } from './auth.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// O FormsModule é usado juntamente com o 'ngmodel' dos templates
import { Component, OnInit, EventEmitter } from '@angular/core';
import { Usuario } from './usuario';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
  export class LoginComponent implements OnInit {

    private usuario: Usuario = new Usuario ();

    mostrarMenuEmitter = new EventEmitter<boolean>();

  constructor(private authService: AuthService) { }

  ngOnInit() {
  }

  fazerLogin() {
//    console.log(this.usuario);
      this.authService.fazerLogin(this.usuario);
  }
}
