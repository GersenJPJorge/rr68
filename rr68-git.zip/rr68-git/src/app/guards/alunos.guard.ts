import { RouterStateSnapshot } from '@angular/router';
import { ActivatedRouteSnapshot } from '@angular/router';
import { AuthService } from '../login/auth.service';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';
import { CanActivateChild } from '@angular/router';

@Injectable()

export class AlunosGuard implements CanActivateChild {

// constructor(
//    private authService: AuthService,
//    private router: Router
//  ) { }

  canActivateChild(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
//            console.log(route);      
//            console.log(state);

        if (state.url.includes('editar')){
            // alert('Usuário sem acesso');
            // return Observable.of(false)
        }
            return true;
      }
    }
