import { Observable } from 'rxjs/Observable';
import { Injectable, Component } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, CanDeactivate } from '@angular/router';
import { AlunoFormComponent } from './../alunos/aluno-form/aluno-form.component';
import { IFormCandeactivate } from "./iform-candeactivate";

@Injectable()

export class AlunosDeactivateGuard implements CanDeactivate<IFormCandeactivate> {

   canDeactivate(
           component: IFormCandeactivate,
           route: ActivatedRouteSnapshot,
           state: RouterStateSnapshot
       ): Observable<boolean>|Promise<boolean>|boolean {
           console.log('guarda de desativação');

//          return component.podeMudarRota();

            return component.podeDesativar();   
}
 }
